import React from 'react'

const ButtonLoader = () => {
  return (
     <div className="animate-spin border-2 border-white border-t-transparent rounded-full w-4 h-4"></div>

  )
}

export default ButtonLoader