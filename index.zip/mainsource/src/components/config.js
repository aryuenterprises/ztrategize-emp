
// export const API_URL = "http://192.168.29.54:5000/";
export const API_URL = "https://hrms.ztrategize.com/";

// export const API_URL = "http://192.168.0.171:5000/";
// export const API_URL = "http://localhost:5000/";


